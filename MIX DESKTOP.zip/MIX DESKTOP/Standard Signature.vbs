' Signature Folder: %appdata%\Microsoft\Signatures

'Option Explicit
On Error Resume Next

   Dim strSigName
   Dim strFullName, strTitle, strDepartment, strOffice, strAddress, strCity, strCompany, strZip, strCountry, strPhone, strMobile, strEmail, strWeb, strCorpEmail
   Dim boolUpdateStyle

'==========================================================================
' Some script variables
'==========================================================================

'  Name signature
   strSigName  = "Standard Signature"
'  If signature exists, overwrite (true) or leave alone (false)?
   boolUpdateStyle = true

'==========================================================================
' Set some static information
'==========================================================================

'  Company information
   strCompany	= "AB Bank Limited"
   strWeb		= "www.abbl.com"
   strFacebook	= "https://www.facebook.com/abbanklimited/"
   strInstagram	= "https://www.instagram.com/abbanklimited/"
   strLinkedIn	= "https://www.linkedin.com/company/ab-bank-limited/"
   strTwitter	= "https://twitter.com/ABBankLimited"
   strYouTube	= "https://www.youtube.com/c/abblbd"

'  Fallback email address when no address is found
   strCorpEmail = "administrator@abbl.com"

'==========================================================================
' Read User's Active Directory information
'==========================================================================
   Dim objSysInfo, objUser

   Set objSysInfo = CreateObject("ADSystemInfo")
   Set objUser    = GetObject("LDAP://" & objSysInfo.Username)

   strFullName		= objUser.cn
   strTitle			= objUser.title
   strDepartment	= objUser.department
   strOffice		= objUser.physicalDeliveryOfficeName
   strAddress		= objUser.streetAddress
   strCity			= objUser.st
   strZip			= objUser.postalCode
   strCountry		= objUser.co
   strPhone			= objUser.telephoneNumber
   strMobile		= objUser.mobile
   strEmail			= objuser.EmailAddress

   If Trim(strTitle) = "" Then strTitle = "_"
   If Trim(strEmail) = "" Then strEmail = strCorpEmail

   Set objUser    = Nothing
   Set objSysInfo = Nothing


'==========================================================================
' Get Signature Folder
'==========================================================================
   Dim objShell
   Set objShell = CreateObject("WScript.Shell")
   strSigFolder = ObjShell.ExpandEnvironmentStrings("%appdata%") & "\Microsoft\Signatures\"
   Set objShell = Nothing


'==========================================================================
' Get Signature Folder
'==========================================================================
   Dim objFSO, objFile
   Set objFSO   = CreateObject("Scripting.FileSystemObject")

   If Not (objFSO.FolderExists(strSigFolder)) Then
      Call objFSO.CreateFolder(strSigFolder)
   End If

   strHTMFile = strSigFolder & strSigName & ".htm"
   strRTFFile = strSigFolder & strSigName & ".rtf"
   strTXTFile = strSigFolder & strSigName & ".txt"


'==========================================================================
' Create HTM File
'==========================================================================
'/ = " & Chr(47) & "

   Err.Clear
   Set objFile = objFSO.CreateTextFile(strHTMFile, boolUpdateStyle, False)
   If Err.Number = 0 Then
      objFile.Write "<!doctype html><html><head>"&vbCrLf
      objFile.Write "<style>"&vbCrLf
      objFile.Write "body { font-family: Verdana; font-style: normal; font-size: 14px; color: #000000; }"&vbCrLf
      objFile.Write ".red { color: Red; }"&vbCrLf
      objFile.Write ".small { font-size: 10px; }"&vbCrLf
      objFile.Write ".redAndBold { color: Red; font-weight:bolder; }"&vbCrLf
      objFile.Write "<" & Chr(47) & "style>"&vbCrLf
      objFile.Write "<title><" & Chr(47) & "title><" & Chr(47) & "head>"&vbCrLf
      objFile.Write "<body>"&vbCrLf
      objFile.Write "<p><br>With best regards,<br><br>"&vbCrLf
      objFile.Write "<span class=""red"">" & strFullName & "<" & Chr(47) & "span><br>"&vbCrLf
      objFile.Write "<span class=""small"">" & strTitle & ", " & strDepartment & ", " & strOffice &" <span class=""redAndBold"">|<" & Chr(47) & "span> " & strCompany & " <span class=""redAndBold"">|<" & Chr(47) & "span> " & strAddress & ", " & strCity & " " & strZip & ", " & strCountry & "<br>"&vbCrLf
      objFile.Write "PABX: " & strPhone & " <span class=""redAndBold"">|<" & Chr(47) & "span> Cell: " & strMobile & " <span class=""redAndBold"">|<" & Chr(47) & "span> Email: <a href=""mailto:" & strEmail & """>" & strEmail & "<" & Chr(47) & "a> <span class=""redAndBold"">|<" & Chr(47) & "span> Web: <a href=" & strWeb & ">" & strWeb & "<" & Chr(47) & "a><br><br><br>"&vbCrLf
'	  objFile.Write "<a href=" & strFacebook & ">Facebook<" & Chr(47) & "a> <span class=""redAndBold"">|<" & Chr(47) & "span> <a href=" & strInstagram & ">Instagram<" & Chr(47) & "a> <span class=""redAndBold"">|<" & Chr(47) & "span> <a href=" & strLinkedIn & ">LinkedIn<" & Chr(47) & "a> <span class=""redAndBold"">|<" & Chr(47) & "span> <a href=" & strTwitter & ">Twitter<" & Chr(47) & "a> <span class=""redAndBold"">|<" & Chr(47) & "span> <a href=" & strYouTube & ">YouTube<" & Chr(47) & "a>"&vbCrLf
      objFile.Write "<" & Chr(47) & "span><" & Chr(47) & "p><" & Chr(47) & "body><" & Chr(47) & "html>"&vbCrLf

'==========================================================================
' Create TXT File
'==========================================================================
   Err.Clear
   Set objFile = objFSO.CreateTextFile(strTXTFile, boolUpdateStyle, False)
   If Err.Number = 0 Then
      objFile.Write vbCrLf
      objFile.Write "With best regards," & vbCrLf & vbCrLf
      objFile.Write strFullName & vbCrLf
      objFile.Write strTitle & ", " & strDepartment & ", " & strOffice & " | " & strCompany & " | " & strAddress & ", " & strCity & " " & strZip & ", " & strCountry & vbCrLf
      objFile.Write "PABX: " & strPhone & " | Cell: " & strMobile & " | Email: " & strEmail & " | Web: " & strWeb & vbCrLf
   End If


'==========================================================================
' Create RTF File
'==========================================================================
   Err.Clear
   Set objFile = objFSO.CreateTextFile(strRTFFile, boolUpdateStyle, False)
   If Err.Number = 0 Then
      objfile.Write "{\rtf1\ansi\ansicpg1252\deff0\deflang1033 {\fonttbl {\f0\fswiss\fprq2\fcharset0 Verdana;}}" & vbCrLF
      objfile.Write "{\colortbl;\red0\green0\blue0;\red255\green0\blue0;}" & vbCrLF
      objfile.Write "{\*\generator Msftedit 5.41.15.1507;}\viewkind4\uc1\pard\sb100\sa100\cf1\lang2057\f0\fs20" & vbCrLF
	  objfile.Write "\line With best regards,\line \line " 
	  objfile.Write "\cf2" & strFullName & "\line "
      objFile.Write "\cf1\fs14" & strTitle & ", " & strDepartment & ", " & strOffice & " \cf2\b | \cf1\b0 " & strCompany & " \cf2\b | \cf1\b0 " & strAddress & ", " & strCity & " " & strZip & ", " & strCountry & "\line "
      objfile.Write "PABX: " & strPhone & " \cf2\b | \cf1\b0 Cell: " & strMobile & " \cf2\b | \cf1\b0 Email: {\field{\*\fldinst{HYPERLINK ""mailto:" & strEmail & """}}{\fldrslt{\ul " & strEmail & "}}}\ulnone\cf2\b  | \cf1\b0 Web: {\field{\*\fldinst{HYPERLINK """ & strWeb & """}}{\fldrslt{\ul " & strWeb & "}}}\ulnone\line " & vbCrLF
	  objfile.Write "}" & vbCrLF
      objFile.Close
   End If


'==========================================================================
' Tidy-up
'==========================================================================
   set objFile = Nothing
   set objFSO  = Nothing
   End If
